module.exports = class BadRequestError extends Error {}
