module.exports = class AlreadyExistsError extends Error {}
