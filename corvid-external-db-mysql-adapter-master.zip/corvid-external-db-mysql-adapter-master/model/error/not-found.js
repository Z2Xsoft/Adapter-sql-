module.exports = class NotFoundError extends Error {}
