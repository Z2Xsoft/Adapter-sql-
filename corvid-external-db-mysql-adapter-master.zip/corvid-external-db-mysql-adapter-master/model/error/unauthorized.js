module.exports = class UnauthorizedError extends Error {}
